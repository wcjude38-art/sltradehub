import { useState, useEffect, useCallback } from "react";

// ══════════════════════════════════════════════
//  CONFIG — ඔබේ admin password මෙහි වෙනස් කරන්න
// ══════════════════════════════════════════════
const ADMIN_PASSWORD = "/Milano1234()";

const CATEGORIES = [
  "Spices & Herbs","Tea & Coffee","Fruits & Vegetables",
  "Oils & Extracts","Textiles & Fabrics","Gems & Jewellery",
  "Handicrafts","Processed Foods","Cosmetics & Wellness","Other"
];

const ORIGINS = ["Sri Lanka","Italy","India","Dubai","Singapore","Other"];
const DESTINATIONS = ["Italy","EU","UK","USA","Middle East","Asia","Worldwide"];

const DEFAULT_PRODUCTS = [
  {
    id: "p1", name: "Ceylon Cinnamon Alba Quills",
    category: "Spices & Herbs", origin: "Sri Lanka", destination: "Italy",
    price: "€18/100g", minOrder: "100g", status: "active",
    desc: "World's finest true cinnamon — paper-thin quills, EU organic certified.",
    tags: ["Organic","Premium","EU Certified"], lang: { si: "Ceylon Alba කුරුඳු", it: "Cannella Ceylon Alba" },
    color: "#8B3A1A"
  },
  {
    id: "p2", name: "Ceylon Black Tea FBOP",
    category: "Tea & Coffee", origin: "Sri Lanka", destination: "EU",
    price: "€22/250g", minOrder: "250g", status: "active",
    desc: "High-grown Uva province black tea. Bright liquor, bold character.",
    tags: ["High-Grown","Export Grade"], lang: { si: "Ceylon Black Tea", it: "Tè Nero Ceylon" },
    color: "#2C1810"
  }
];

// ── Colours
const C = {
  navy: "#0B1628", navyMid: "#162240", navyLight: "#1E305A",
  gold: "#C9933A", goldLight: "#E8C06A", goldPale: "#F5E4C0",
  cream: "#F9F5EE", white: "#FFFFFF",
  red: "#C0392B", green: "#1A7A4A", orange: "#D4680A",
  text: "#0B1628", textMid: "#3A4A6A", textLight: "#7A8AA0"
};

// ── Helpers
function uid() { return "p" + Date.now() + Math.random().toString(36).slice(2,6); }

function StatusBadge({ s }) {
  const map = { active: [C.green,"Active"], inactive: [C.red,"Inactive"], draft: [C.orange,"Draft"] };
  const [col, label] = map[s] || [C.textLight, s];
  return (
    <span style={{
      background: col+"18", color: col, border: `1px solid ${col}40`,
      fontSize:10, letterSpacing:2, textTransform:"uppercase",
      padding:"3px 10px", borderRadius:2, fontWeight:500
    }}>{label}</span>
  );
}

function Tag({ label }) {
  return (
    <span style={{
      background: C.goldPale, color: C.navy,
      fontSize:10, letterSpacing:1.5, textTransform:"uppercase",
      padding:"3px 9px", borderRadius:2, fontWeight:500
    }}>{label}</span>
  );
}

// ══════════════════════════════════════════════
//  ADMIN PANEL
// ══════════════════════════════════════════════
function AdminPanel({ products, onSave, onLogout }) {
  const [view, setView] = useState("list"); // list | form
  const [editing, setEditing] = useState(null);
  const [confirmDel, setConfirmDel] = useState(null);
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("All");

  const blank = {
    id:"", name:"", category: CATEGORIES[0], origin: ORIGINS[0],
    destination: DESTINATIONS[0], price:"", minOrder:"",
    status:"active", desc:"", tags:[], lang:{si:"",it:""}, color:"#1E305A"
  };

  const [form, setForm] = useState(blank);
  const [tagInput, setTagInput] = useState("");

  function openNew() { setForm({...blank, id: uid()}); setEditing(null); setView("form"); }
  function openEdit(p) { setForm({...p, tags:[...(p.tags||[])], lang:{...p.lang}}); setEditing(p.id); setView("form"); }

  function saveForm() {
    if (!form.name.trim()) return;
    const updated = editing
      ? products.map(p => p.id === editing ? form : p)
      : [...products, form];
    onSave(updated);
    setView("list");
  }

  function deleteProduct(id) {
    onSave(products.filter(p => p.id !== id));
    setConfirmDel(null);
  }

  function addTag() {
    if (!tagInput.trim()) return;
    setForm(f => ({...f, tags: [...(f.tags||[]), tagInput.trim()]}));
    setTagInput("");
  }

  const filtered = products.filter(p => {
    const q = search.toLowerCase();
    const matchQ = !q || p.name.toLowerCase().includes(q) || p.desc?.toLowerCase().includes(q);
    const matchC = filterCat === "All" || p.category === filterCat;
    return matchQ && matchC;
  });

  const inp = (field, val) => setForm(f => ({...f, [field]: val}));

  // ── FORM VIEW
  if (view === "form") return (
    <div style={{padding:"30px 40px", maxWidth:760, margin:"0 auto"}}>
      <div style={{display:"flex", alignItems:"center", gap:16, marginBottom:32}}>
        <button onClick={()=>setView("list")} style={{...btnSm, background:"transparent", border:`1px solid ${C.navyLight}`, color:C.textMid}}>← Back</button>
        <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:26, color:C.navy, margin:0}}>
          {editing ? "Edit Product" : "New Product"}
        </h2>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:24}}>
        <FormField label="Product Name *">
          <input style={inputStyle} value={form.name} onChange={e=>inp("name",e.target.value)} placeholder="e.g. Ceylon Cinnamon Alba" />
        </FormField>
        <FormField label="Category">
          <select style={inputStyle} value={form.category} onChange={e=>inp("category",e.target.value)}>
            {CATEGORIES.map(c=><option key={c}>{c}</option>)}
          </select>
        </FormField>
        <FormField label="Origin">
          <select style={inputStyle} value={form.origin} onChange={e=>inp("origin",e.target.value)}>
            {ORIGINS.map(o=><option key={o}>{o}</option>)}
          </select>
        </FormField>
        <FormField label="Destination">
          <select style={inputStyle} value={form.destination} onChange={e=>inp("destination",e.target.value)}>
            {DESTINATIONS.map(d=><option key={d}>{d}</option>)}
          </select>
        </FormField>
        <FormField label="Price (e.g. €18/100g)">
          <input style={inputStyle} value={form.price} onChange={e=>inp("price",e.target.value)} placeholder="€0.00/unit" />
        </FormField>
        <FormField label="Min. Order">
          <input style={inputStyle} value={form.minOrder} onChange={e=>inp("minOrder",e.target.value)} placeholder="e.g. 500g, 1kg, 1 MOQ" />
        </FormField>
        <FormField label="Status">
          <select style={inputStyle} value={form.status} onChange={e=>inp("status",e.target.value)}>
            <option value="active">Active (Visible)</option>
            <option value="draft">Draft (Hidden)</option>
            <option value="inactive">Inactive</option>
          </select>
        </FormField>
        <FormField label="Card Colour">
          <div style={{display:"flex", gap:10, alignItems:"center"}}>
            <input type="color" value={form.color} onChange={e=>inp("color",e.target.value)}
              style={{width:44, height:36, border:"none", cursor:"pointer", borderRadius:4}} />
            <span style={{fontSize:13, color:C.textMid}}>{form.color}</span>
          </div>
        </FormField>
      </div>

      <FormField label="Description" style={{marginTop:24}}>
        <textarea style={{...inputStyle, height:80, resize:"none"}}
          value={form.desc} onChange={e=>inp("desc",e.target.value)}
          placeholder="Brief product description..." />
      </FormField>

      <FormField label="Tags (press Enter to add)" style={{marginTop:24}}>
        <div style={{display:"flex", gap:8, flexWrap:"wrap", marginBottom:8}}>
          {(form.tags||[]).map((t,i) => (
            <span key={i} style={{
              background:C.goldPale, color:C.navy, fontSize:11,
              padding:"4px 10px", borderRadius:2, cursor:"pointer",
              display:"flex", gap:6, alignItems:"center"
            }}>
              {t}
              <span onClick={()=>setForm(f=>({...f, tags:f.tags.filter((_,j)=>j!==i)}))}
                style={{color:C.red, fontWeight:"bold"}}>×</span>
            </span>
          ))}
        </div>
        <div style={{display:"flex", gap:8}}>
          <input style={{...inputStyle, flex:1}} value={tagInput}
            onChange={e=>setTagInput(e.target.value)}
            onKeyDown={e=>e.key==="Enter" && addTag()}
            placeholder="Organic, Premium, Certified..." />
          <button onClick={addTag} style={{...btnSm, background:C.navy, color:C.goldLight}}>Add</button>
        </div>
      </FormField>

      <div style={{borderTop:`1px solid #e8e0d0`, marginTop:28, paddingTop:24, marginBottom:8}}>
        <p style={{fontSize:11, letterSpacing:2, textTransform:"uppercase", color:C.textLight, marginBottom:16}}>Multilingual Names (optional)</p>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:16}}>
          <FormField label="සිංහල නම">
            <input style={inputStyle} value={form.lang?.si||""} onChange={e=>setForm(f=>({...f,lang:{...f.lang,si:e.target.value}}))} placeholder="Sinhala name" />
          </FormField>
          <FormField label="Nome Italiano">
            <input style={inputStyle} value={form.lang?.it||""} onChange={e=>setForm(f=>({...f,lang:{...f.lang,it:e.target.value}}))} placeholder="Italian name" />
          </FormField>
        </div>
      </div>

      <div style={{display:"flex", gap:12, marginTop:32}}>
        <button onClick={saveForm} style={{...btnPrimary, flex:1}}>
          {editing ? "💾 Save Changes" : "✓ Create Product"}
        </button>
        <button onClick={()=>setView("list")} style={{...btnSm, padding:"12px 24px", background:"transparent", border:`1px solid #ccc`, color:C.textMid}}>
          Cancel
        </button>
      </div>
    </div>
  );

  // ── LIST VIEW
  return (
    <div style={{padding:"30px 40px"}}>
      {/* Header */}
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:32}}>
        <div>
          <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:28, color:C.navy, margin:0}}>
            Product Manager
          </h2>
          <p style={{fontSize:13, color:C.textLight, margin:"4px 0 0"}}>
            {products.length} products · {products.filter(p=>p.status==="active").length} active
          </p>
        </div>
        <div style={{display:"flex", gap:12}}>
          <button onClick={openNew} style={btnPrimary}>+ New Product</button>
          <button onClick={onLogout} style={{...btnSm, background:"transparent", border:`1px solid ${C.navyLight}`, color:C.textMid}}>Logout</button>
        </div>
      </div>

      {/* Filters */}
      <div style={{display:"flex", gap:12, marginBottom:24, flexWrap:"wrap"}}>
        <input
          style={{...inputStyle, maxWidth:260, padding:"10px 14px"}}
          placeholder="🔍  Search products..."
          value={search} onChange={e=>setSearch(e.target.value)}
        />
        <select style={{...inputStyle, maxWidth:200}} value={filterCat} onChange={e=>setFilterCat(e.target.value)}>
          <option value="All">All Categories</option>
          {CATEGORIES.map(c=><option key={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      {filtered.length === 0 ? (
        <div style={{textAlign:"center", padding:"60px 0", color:C.textLight}}>
          <div style={{fontSize:40, marginBottom:12}}>📦</div>
          <p>No products found. <span style={{color:C.gold, cursor:"pointer"}} onClick={openNew}>Add your first one →</span></p>
        </div>
      ) : (
        <div style={{display:"grid", gap:2}}>
          {/* Table header */}
          <div style={{
            display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr 100px 100px",
            padding:"10px 20px", background:C.navy,
            fontSize:10, letterSpacing:2, textTransform:"uppercase", color:C.goldLight,
            borderRadius:"6px 6px 0 0"
          }}>
            <span>Product</span><span>Category</span><span>Route</span>
            <span>Price</span><span>Status</span><span>Actions</span>
          </div>
          {filtered.map((p, i) => (
            <div key={p.id} style={{
              display:"grid", gridTemplateColumns:"2fr 1fr 1fr 1fr 100px 100px",
              padding:"16px 20px", alignItems:"center",
              background: i%2===0 ? C.cream : C.white,
              borderBottom:`1px solid #e8e0d0`,
              transition:"background 0.2s"
            }}
            onMouseEnter={e=>e.currentTarget.style.background="#f0e8d8"}
            onMouseLeave={e=>e.currentTarget.style.background=i%2===0?C.cream:C.white}
            >
              <div style={{display:"flex", gap:12, alignItems:"center"}}>
                <div style={{
                  width:32, height:32, borderRadius:4,
                  background: p.color||C.navy, flexShrink:0,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontSize:14
                }}>📦</div>
                <div>
                  <div style={{fontWeight:500, fontSize:14, color:C.navy}}>{p.name}</div>
                  <div style={{fontSize:11, color:C.textLight}}>{p.minOrder} min order</div>
                </div>
              </div>
              <span style={{fontSize:13, color:C.textMid}}>{p.category}</span>
              <span style={{fontSize:13, color:C.textMid}}>{p.origin} → {p.destination}</span>
              <span style={{fontFamily:"'Playfair Display',serif", fontSize:15, color:C.navy, fontWeight:400}}>{p.price}</span>
              <StatusBadge s={p.status} />
              <div style={{display:"flex", gap:6}}>
                <button onClick={()=>openEdit(p)} style={{...iconBtn, color:C.navy}}>✏️</button>
                <button onClick={()=>setConfirmDel(p.id)} style={{...iconBtn, color:C.red}}>🗑</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete confirm */}
      {confirmDel && (
        <div style={{
          position:"fixed", inset:0, background:"rgba(0,0,0,0.5)",
          display:"flex", alignItems:"center", justifyContent:"center", zIndex:999
        }}>
          <div style={{background:C.white, borderRadius:8, padding:"36px 48px", textAlign:"center", maxWidth:380}}>
            <div style={{fontSize:32, marginBottom:12}}>⚠️</div>
            <h3 style={{fontFamily:"'Playfair Display',serif", color:C.navy, marginBottom:8}}>Delete Product?</h3>
            <p style={{fontSize:14, color:C.textMid, marginBottom:28}}>
              {products.find(p=>p.id===confirmDel)?.name}<br/>
              <span style={{fontSize:12, color:C.red}}>This cannot be undone.</span>
            </p>
            <div style={{display:"flex", gap:12}}>
              <button onClick={()=>deleteProduct(confirmDel)}
                style={{...btnPrimary, background:C.red, flex:1}}>Delete</button>
              <button onClick={()=>setConfirmDel(null)}
                style={{...btnSm, padding:"12px 24px", flex:1, background:"transparent", border:`1px solid #ccc`, color:C.textMid}}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════
//  PUBLIC STOREFRONT
// ══════════════════════════════════════════════
function Storefront({ products, lang, setLang }) {
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null);
  const [inquiry, setInquiry] = useState({name:"",email:"",msg:""});
  const [sent, setSent] = useState(false);

  const activeProducts = products.filter(p => p.status === "active");
  const cats = ["All", ...new Set(activeProducts.map(p=>p.category))];

  const visible = activeProducts.filter(p => {
    const q = search.toLowerCase();
    return (filter==="All" || p.category===filter) &&
      (!q || p.name.toLowerCase().includes(q) || p.desc?.toLowerCase().includes(q));
  });

  const t = {
    en: { title:"SL Trade Hub", hero:"Your Trusted Import / Export Partner", sub:"Sri Lanka ↔ Italy & EU · Premium Products · Direct Trade",
      shop:"Browse Products", contact:"Get Quote", all:"All",
      origin:"Origin", dest:"Destination", minOrder:"Min. Order",
      inquiry:"Send Inquiry", close:"Close", name:"Your Name",
      email:"Email", message:"Message", send:"Send", thanks:"Inquiry sent! We'll reply within 24 hours.",
      search:"Search products..." },
    si: { title:"SL Trade Hub", hero:"විශ්වාසනීය Import / Export සහකරු", sub:"ශ්‍රී ලංකාව ↔ Italy & EU · ප්‍රිමියම් Products",
      shop:"Products බලන්න", contact:"Quote ගන්න", all:"සියල්ල",
      origin:"මූලාශ්‍රය", dest:"ගමනාන්තය", minOrder:"අවම ඇණවුම",
      inquiry:"ඇණවුම යවන්න", close:"වසන්න", name:"ඔබේ නම",
      email:"Email", message:"පණිවිඩය", send:"යවන්න", thanks:"ඇණවුම යවා ඇත!",
      search:"Products සොයන්න..." },
    it: { title:"SL Trade Hub", hero:"Il Tuo Partner di Fiducia Import / Export", sub:"Sri Lanka ↔ Italia & UE · Prodotti Premium",
      shop:"Esplora Prodotti", contact:"Richiedi Preventivo", all:"Tutti",
      origin:"Origine", dest:"Destinazione", minOrder:"Ordine Minimo",
      inquiry:"Invia Richiesta", close:"Chiudi", name:"Il Tuo Nome",
      email:"Email", message:"Messaggio", send:"Invia", thanks:"Richiesta inviata!",
      search:"Cerca prodotti..." }
  }[lang];

  return (
    <div style={{fontFamily:"'Jost',sans-serif", background:C.cream, minHeight:"100vh"}}>
      {/* Nav */}
      <nav style={{
        background:C.navy, padding:"0 50px",
        display:"flex", justifyContent:"space-between", alignItems:"center",
        height:64, position:"sticky", top:0, zIndex:100,
        boxShadow:"0 2px 20px rgba(0,0,0,0.3)"
      }}>
        <span style={{fontFamily:"'Playfair Display',serif", fontSize:22, color:C.goldLight, letterSpacing:1}}>
          {t.title}
        </span>
        <div style={{display:"flex", gap:6}}>
          {["en","si","it"].map(l=>(
            <button key={l} onClick={()=>setLang(l)} style={{
              background: lang===l ? C.gold : "transparent",
              border:`1px solid ${lang===l?C.gold:"rgba(201,147,58,0.3)"}`,
              color: lang===l ? C.navy : C.goldLight,
              fontSize:11, letterSpacing:2, padding:"5px 12px",
              cursor:"pointer", borderRadius:2, fontWeight:500,
              textTransform:"uppercase", transition:"all 0.2s"
            }}>{l==="si"?"සිං":l.toUpperCase()}</button>
          ))}
        </div>
      </nav>

      {/* Hero */}
      <div style={{
        background:`linear-gradient(135deg, ${C.navy} 0%, ${C.navyMid} 60%, #1A3060 100%)`,
        padding:"80px 50px", textAlign:"center", position:"relative", overflow:"hidden"
      }}>
        <div style={{position:"absolute", inset:0, backgroundImage:"radial-gradient(circle at 20% 50%, rgba(201,147,58,0.15) 0%, transparent 60%), radial-gradient(circle at 80% 30%, rgba(201,147,58,0.08) 0%, transparent 50%)"}} />
        <p style={{fontSize:11, letterSpacing:5, textTransform:"uppercase", color:C.gold, marginBottom:16, position:"relative"}}>
          Sri Lanka · Italy · EU
        </p>
        <h1 style={{fontFamily:"'Playfair Display',serif", fontSize:"clamp(36px,6vw,72px)", color:C.cream, fontWeight:400, lineHeight:1.1, margin:"0 0 16px", position:"relative"}}>
          {t.hero}
        </h1>
        <p style={{fontSize:16, color:"rgba(249,245,238,0.6)", marginBottom:40, position:"relative"}}>{t.sub}</p>
        <div style={{display:"flex", gap:12, justifyContent:"center", flexWrap:"wrap", position:"relative"}}>
          <a href="#products" style={{...btnPrimary, textDecoration:"none"}}>{t.shop}</a>
          <a href="#contact" style={{
            ...btnPrimary, background:"transparent",
            border:`1px solid rgba(249,245,238,0.35)`, color:C.cream,
            textDecoration:"none"
          }}>{t.contact}</a>
        </div>
        {/* Stats */}
        <div style={{display:"flex", gap:40, justifyContent:"center", marginTop:60, flexWrap:"wrap", position:"relative"}}>
          {[
            ["SL → EU","Direct Trade"],
            [activeProducts.length+"","Active Products"],
            ["100%","Certified Quality"],
            ["24hr","Response Time"]
          ].map(([n,l])=>(
            <div key={l} style={{textAlign:"center", borderLeft:`2px solid rgba(201,147,58,0.3)`, paddingLeft:16}}>
              <div style={{fontFamily:"'Playfair Display',serif", fontSize:32, color:C.gold, fontWeight:400}}>{n}</div>
              <div style={{fontSize:10, letterSpacing:2, textTransform:"uppercase", color:"rgba(249,245,238,0.5)"}}>{l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Products */}
      <div id="products" style={{padding:"70px 50px"}}>
        <div style={{textAlign:"center", marginBottom:50}}>
          <p style={{fontSize:10, letterSpacing:5, textTransform:"uppercase", color:C.gold, marginBottom:12}}>Catalogue</p>
          <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:42, color:C.navy, fontWeight:400, margin:0}}>
            {visible.length} <em style={{color:C.navyMid, fontStyle:"italic"}}>Products</em>
          </h2>
        </div>

        {/* Filters */}
        <div style={{display:"flex", gap:10, justifyContent:"center", flexWrap:"wrap", marginBottom:40}}>
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder={t.search}
            style={{
              border:`1px solid #ddd`, borderRadius:3, padding:"9px 16px",
              fontSize:13, background:C.white, color:C.navy, outline:"none",
              fontFamily:"'Jost',sans-serif", minWidth:200
            }} />
          {cats.map(c=>(
            <button key={c} onClick={()=>setFilter(c)} style={{
              background: filter===c ? C.navy : C.white,
              color: filter===c ? C.goldLight : C.textMid,
              border:`1px solid ${filter===c?C.navy:"#ddd"}`,
              padding:"8px 16px", fontSize:11, letterSpacing:1.5,
              textTransform:"uppercase", cursor:"pointer", borderRadius:3,
              fontFamily:"'Jost',sans-serif", transition:"all 0.2s",
              fontWeight: filter===c ? 500 : 300
            }}>{c==="All"?t.all:c}</button>
          ))}
        </div>

        {/* Grid */}
        {visible.length === 0 ? (
          <div style={{textAlign:"center", padding:"60px 0", color:C.textLight}}>
            <div style={{fontSize:48, marginBottom:16}}>📦</div>
            <p style={{fontSize:15}}>No products found.</p>
          </div>
        ) : (
          <div style={{
            display:"grid",
            gridTemplateColumns:"repeat(auto-fill, minmax(300px, 1fr))",
            gap:24, maxWidth:1200, margin:"0 auto"
          }}>
            {visible.map(p => (
              <div key={p.id} onClick={()=>setSelected(p)}
                style={{
                  background:C.white, cursor:"pointer", overflow:"hidden",
                  borderRadius:4, border:`1px solid #e8e0d0`,
                  transition:"transform 0.3s, box-shadow 0.3s",
                  boxShadow:"0 2px 12px rgba(0,0,0,0.06)"
                }}
                onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-4px)";e.currentTarget.style.boxShadow="0 12px 32px rgba(0,0,0,0.12)";}}
                onMouseLeave={e=>{e.currentTarget.style.transform="none";e.currentTarget.style.boxShadow="0 2px 12px rgba(0,0,0,0.06)";}}
              >
                <div style={{
                  height:160, background:p.color||C.navy,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  position:"relative", overflow:"hidden"
                }}>
                  <span style={{fontSize:60, opacity:0.15, position:"absolute"}}>📦</span>
                  <div style={{position:"relative", textAlign:"center"}}>
                    <div style={{fontFamily:"'Playfair Display',serif", fontSize:28, color:"rgba(255,255,255,0.85)", fontWeight:400, fontStyle:"italic"}}>
                      {lang==="si" && p.lang?.si ? p.lang.si.split(" ")[0] :
                       lang==="it" && p.lang?.it ? p.lang.it.split(" ")[0] : p.name.split(" ")[0]}
                    </div>
                    <div style={{fontSize:10, letterSpacing:3, textTransform:"uppercase", color:"rgba(255,255,255,0.5)", marginTop:4}}>
                      {p.origin}
                    </div>
                  </div>
                </div>
                <div style={{padding:24}}>
                  <div style={{fontSize:10, letterSpacing:2.5, textTransform:"uppercase", color:C.gold, marginBottom:8}}>
                    {p.category}
                  </div>
                  <h3 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:C.navy, margin:"0 0 8px", fontWeight:400}}>
                    {lang==="si" && p.lang?.si ? p.lang.si :
                     lang==="it" && p.lang?.it ? p.lang.it : p.name}
                  </h3>
                  <p style={{fontSize:13, color:C.textMid, lineHeight:1.6, margin:"0 0 16px", fontWeight:300}}>
                    {p.desc}
                  </p>
                  <div style={{display:"flex", gap:6, flexWrap:"wrap", marginBottom:16}}>
                    {(p.tags||[]).slice(0,3).map(t=><Tag key={t} label={t}/>)}
                  </div>
                  <div style={{
                    display:"flex", justifyContent:"space-between", alignItems:"center",
                    borderTop:`1px solid #f0e8d8`, paddingTop:16
                  }}>
                    <div>
                      <div style={{fontFamily:"'Playfair Display',serif", fontSize:22, color:C.navy}}>{p.price}</div>
                      <div style={{fontSize:11, color:C.textLight}}>{t.minOrder}: {p.minOrder}</div>
                    </div>
                    <div style={{
                      background:C.navy, color:C.goldLight, padding:"10px 18px",
                      fontSize:11, letterSpacing:2, textTransform:"uppercase", fontWeight:500, borderRadius:2
                    }}>View →</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Contact */}
      <div id="contact" style={{
        background:C.navy, padding:"80px 50px", display:"grid",
        gridTemplateColumns:"1fr 1fr", gap:80, maxWidth:"100%"
      }}>
        <div>
          <p style={{fontSize:10, letterSpacing:5, textTransform:"uppercase", color:C.gold, marginBottom:16}}>Contact</p>
          <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:40, color:C.cream, fontWeight:400, margin:"0 0 24px", lineHeight:1.2}}>
            {t.inquiry}
          </h2>
          <p style={{fontSize:14, color:"rgba(249,245,238,0.6)", lineHeight:1.8, marginBottom:40}}>
            {lang==="si" ? "ඕනෙම product සඳහා wholesale quote ගන්න. පැය 24 ක් ඇතුළත ප්‍රතිචාර." :
             lang==="it" ? "Richiedi un preventivo per qualsiasi prodotto. Risposta entro 24 ore." :
             "Request a quote for any product. We respond within 24 hours, for both retail and wholesale inquiries."}
          </p>
          <div style={{fontSize:13, color:"rgba(249,245,238,0.6)", lineHeight:2.2}}>
            <div>📧 trade@sltradehub.eu</div>
            <div>📍 Milan, Italy</div>
            <div>🌐 Sri Lanka · Italy · EU</div>
          </div>
        </div>
        <div>
          {sent ? (
            <div style={{
              background:"rgba(255,255,255,0.05)", borderRadius:4, padding:40,
              textAlign:"center", border:`1px solid rgba(201,147,58,0.2)`
            }}>
              <div style={{fontSize:40, marginBottom:16}}>✓</div>
              <p style={{color:C.goldLight, fontSize:16}}>{t.thanks}</p>
            </div>
          ) : (
            <div style={{display:"flex", flexDirection:"column", gap:20}}>
              {[
                [t.name, "text", "name"],
                [t.email, "email", "email"]
              ].map(([label, type, key])=>(
                <div key={key}>
                  <label style={{fontSize:10, letterSpacing:3, textTransform:"uppercase", color:C.gold, display:"block", marginBottom:8}}>{label}</label>
                  <input type={type} value={inquiry[key]}
                    onChange={e=>setInquiry(i=>({...i,[key]:e.target.value}))}
                    style={{
                      width:"100%", background:"transparent",
                      border:"none", borderBottom:`1px solid rgba(201,147,58,0.3)`,
                      color:C.cream, padding:"10px 0", fontSize:15,
                      fontFamily:"'Jost',sans-serif", outline:"none", boxSizing:"border-box"
                    }}/>
                </div>
              ))}
              <div>
                <label style={{fontSize:10, letterSpacing:3, textTransform:"uppercase", color:C.gold, display:"block", marginBottom:8}}>{t.message}</label>
                <textarea value={inquiry.msg} onChange={e=>setInquiry(i=>({...i,msg:e.target.value}))}
                  style={{
                    width:"100%", background:"transparent",
                    border:"none", borderBottom:`1px solid rgba(201,147,58,0.3)`,
                    color:C.cream, padding:"10px 0", fontSize:15,
                    fontFamily:"'Jost',sans-serif", outline:"none", resize:"none", height:80, boxSizing:"border-box"
                  }}/>
              </div>
              <button onClick={()=>setSent(true)} style={{...btnPrimary, width:"100%", padding:"16px"}}>
                {t.send} →
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div style={{background:C.text, padding:"24px 50px", display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <span style={{fontFamily:"'Playfair Display',serif", color:C.gold, fontSize:18}}>SL Trade Hub</span>
        <span style={{fontSize:12, color:"rgba(249,245,238,0.3)", letterSpacing:1}}>
          Sri Lanka ↔ Italy · {new Date().getFullYear()}
        </span>
      </div>

      {/* Product Modal */}
      {selected && (
        <div style={{
          position:"fixed", inset:0, background:"rgba(0,0,0,0.7)",
          display:"flex", alignItems:"center", justifyContent:"center",
          zIndex:999, padding:20
        }} onClick={()=>setSelected(null)}>
          <div style={{
            background:C.white, borderRadius:6, maxWidth:560, width:"100%",
            overflow:"hidden", boxShadow:"0 30px 80px rgba(0,0,0,0.3)"
          }} onClick={e=>e.stopPropagation()}>
            <div style={{height:200, background:selected.color||C.navy, display:"flex", alignItems:"center", justifyContent:"center"}}>
              <div style={{fontFamily:"'Playfair Display',serif", fontSize:42, color:"rgba(255,255,255,0.7)", fontStyle:"italic"}}>
                {selected.name.split(" ")[0]}
              </div>
            </div>
            <div style={{padding:32}}>
              <div style={{fontSize:10, letterSpacing:3, textTransform:"uppercase", color:C.gold, marginBottom:8}}>{selected.category}</div>
              <h3 style={{fontFamily:"'Playfair Display',serif", fontSize:26, color:C.navy, margin:"0 0 12px", fontWeight:400}}>
                {lang==="si"&&selected.lang?.si ? selected.lang.si :
                 lang==="it"&&selected.lang?.it ? selected.lang.it : selected.name}
              </h3>
              <p style={{fontSize:14, color:C.textMid, lineHeight:1.7, marginBottom:20}}>{selected.desc}</p>
              <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:16, marginBottom:20}}>
                {[[t.origin, selected.origin],[t.dest, selected.destination],[t.minOrder, selected.minOrder]].map(([l,v])=>(
                  <div key={l} style={{borderLeft:`2px solid ${C.gold}`, paddingLeft:12}}>
                    <div style={{fontSize:10, letterSpacing:2, textTransform:"uppercase", color:C.textLight, marginBottom:4}}>{l}</div>
                    <div style={{fontSize:14, color:C.navy, fontWeight:500}}>{v}</div>
                  </div>
                ))}
              </div>
              <div style={{display:"flex", gap:8, flexWrap:"wrap", marginBottom:24}}>
                {(selected.tags||[]).map(t=><Tag key={t} label={t}/>)}
              </div>
              <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                <div style={{fontFamily:"'Playfair Display',serif", fontSize:30, color:C.navy}}>{selected.price}</div>
                <div style={{display:"flex", gap:10}}>
                  <button onClick={()=>setSelected(null)} style={{...btnSm, background:"transparent", border:`1px solid #ddd`, color:C.textMid}}>{t.close}</button>
                  <button onClick={()=>{setSelected(null);document.getElementById("contact")?.scrollIntoView({behavior:"smooth"});}}
                    style={btnPrimary}>{t.contact} →</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════
//  LOGIN SCREEN
// ══════════════════════════════════════════════
function LoginScreen({ onLogin }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  const [shake, setShake] = useState(false);

  function attempt() {
    if (pw === ADMIN_PASSWORD) { onLogin(); }
    else {
      setErr(true); setShake(true);
      setTimeout(()=>setShake(false), 500);
    }
  }

  return (
    <div style={{
      minHeight:"100vh", background:C.navy,
      display:"flex", alignItems:"center", justifyContent:"center",
      padding:20
    }}>
      <div style={{
        background:C.white, borderRadius:6, padding:"48px 52px",
        maxWidth:400, width:"100%",
        boxShadow:"0 30px 80px rgba(0,0,0,0.4)",
        transform: shake ? "translateX(-8px)" : "none",
        transition: shake ? "transform 0.1s ease" : "transform 0.3s ease"
      }}>
        <div style={{textAlign:"center", marginBottom:36}}>
          <div style={{
            width:54, height:54, borderRadius:"50%",
            background:C.navy, margin:"0 auto 20px",
            display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:22
          }}>🔒</div>
          <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:26, color:C.navy, margin:"0 0 8px", fontWeight:400}}>
            Admin Access
          </h2>
          <p style={{fontSize:13, color:C.textLight, fontWeight:300}}>SL Trade Hub · Product Manager</p>
        </div>
        <div style={{marginBottom:24}}>
          <label style={{fontSize:10, letterSpacing:3, textTransform:"uppercase", color:C.textMid, display:"block", marginBottom:8}}>Password</label>
          <input
            type="password" value={pw}
            onChange={e=>{setPw(e.target.value);setErr(false);}}
            onKeyDown={e=>e.key==="Enter"&&attempt()}
            style={{...inputStyle, border:`1px solid ${err?"#C0392B":"#ddd"}`, borderRadius:3, padding:"12px 14px"}}
            placeholder="Enter admin password"
            autoFocus
          />
          {err && <p style={{color:C.red, fontSize:12, marginTop:6}}>✗ Incorrect password</p>}
        </div>
        <button onClick={attempt} style={{...btnPrimary, width:"100%", padding:"14px"}}>
          Login to Admin Panel
        </button>
        <p style={{fontSize:11, color:C.textLight, textAlign:"center", marginTop:20, fontWeight:300}}>
          Default password: <code style={{background:"#f5f5f5", padding:"2px 6px", borderRadius:2}}>Ceylon2025!</code>
        </p>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════
//  SHARED STYLES
// ══════════════════════════════════════════════
const btnPrimary = {
  background:C.gold, color:C.navy,
  border:"none", padding:"12px 28px",
  fontFamily:"'Jost',sans-serif", fontSize:11,
  letterSpacing:3, textTransform:"uppercase",
  cursor:"pointer", fontWeight:500, borderRadius:2,
  transition:"all 0.2s", display:"inline-block"
};
const btnSm = {
  border:"none", padding:"8px 16px",
  fontFamily:"'Jost',sans-serif", fontSize:11,
  letterSpacing:2, textTransform:"uppercase",
  cursor:"pointer", fontWeight:400, borderRadius:3
};
const iconBtn = {
  background:"transparent", border:"1px solid #e8e0d0",
  padding:"5px 9px", cursor:"pointer", borderRadius:3, fontSize:14
};
const inputStyle = {
  width:"100%", border:"1px solid #e8e0d0",
  borderRadius:3, padding:"10px 12px",
  fontFamily:"'Jost',sans-serif", fontSize:14,
  color:C.navy, outline:"none", background:C.white,
  boxSizing:"border-box"
};
function FormField({ label, children, style }) {
  return (
    <div style={style}>
      <label style={{fontSize:10, letterSpacing:2.5, textTransform:"uppercase", color:C.textMid, display:"block", marginBottom:6, fontWeight:400}}>
        {label}
      </label>
      {children}
    </div>
  );
}

// ══════════════════════════════════════════════
//  ROOT APP
// ══════════════════════════════════════════════
export default function App() {
  const [mode, setMode] = useState("store"); // store | login | admin
  const [products, setProducts] = useState(null);
  const [lang, setLang] = useState("en");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get("sltrade-products");
        if (res && res.value) setProducts(JSON.parse(res.value));
        else setProducts(DEFAULT_PRODUCTS);
      } catch { setProducts(DEFAULT_PRODUCTS); }
      setLoading(false);
    })();
  }, []);

  async function saveProducts(updated) {
    setProducts(updated);
    try { await window.storage.set("sltrade-products", JSON.stringify(updated)); } catch {}
  }

  if (loading) return (
    <div style={{minHeight:"100vh", background:C.navy, display:"flex", alignItems:"center", justifyContent:"center"}}>
      <div style={{textAlign:"center", color:C.gold}}>
        <div style={{fontSize:40, marginBottom:16, animation:"spin 1s linear infinite"}}>⟳</div>
        <style>{`@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}`}</style>
        <p style={{fontFamily:"'Playfair Display',serif", fontSize:18}}>Loading...</p>
      </div>
    </div>
  );

  return (
    <div style={{position:"relative"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400&family=Jost:wght@200;300;400;500&display=swap');
        * { box-sizing: border-box; }
        a { color: inherit; }
        button { font-family: 'Jost', sans-serif; }
      `}</style>

      {/* Admin toggle button */}
      <button
        onClick={()=> mode==="store" ? setMode("login") : setMode("store")}
        title={mode==="store" ? "Admin Login" : "Back to Site"}
        style={{
          position:"fixed", bottom:24, right:24, zIndex:9999,
          background: mode==="store" ? C.navy : C.red,
          color:"white", border:"none",
          width:48, height:48, borderRadius:"50%",
          fontSize:18, cursor:"pointer",
          boxShadow:"0 4px 20px rgba(0,0,0,0.3)",
          display:"flex", alignItems:"center", justifyContent:"center"
        }}
      >
        {mode==="store" ? "⚙️" : "✕"}
      </button>

      {mode === "store" && <Storefront products={products} lang={lang} setLang={setLang} />}
      {mode === "login" && <LoginScreen onLogin={()=>setMode("admin")} />}
      {mode === "admin" && (
        <div style={{minHeight:"100vh", background:C.cream}}>
          {/* Admin nav */}
          <div style={{
            background:C.navy, padding:"0 40px", height:56,
            display:"flex", alignItems:"center", justifyContent:"space-between"
          }}>
            <span style={{fontFamily:"'Playfair Display',serif", color:C.goldLight, fontSize:18}}>
              ⚙️ SL Trade Hub — Admin
            </span>
            <button onClick={()=>setMode("store")} style={{
              ...btnSm, background:"transparent", border:`1px solid rgba(201,147,58,0.3)`,
              color:C.goldLight
            }}>← View Site</button>
          </div>
          <AdminPanel
            products={products}
            onSave={saveProducts}
            onLogout={()=>setMode("store")}
          />
        </div>
      )}
    </div>
  );
}
